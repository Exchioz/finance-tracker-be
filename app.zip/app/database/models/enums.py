import enum

class CategoriesType(enum.Enum):
    INCOME = "income"
    EXPENSE = "expense"